import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-capitulo',
  templateUrl: './crear-capitulo.component.html',
  styleUrls: ['./crear-capitulo.component.css']
})
export class CrearCapituloComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
